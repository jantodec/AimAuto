//
// Created by jie on 5/11/24.
//
#pragma once                // 确保头文件内容只被包含一次

#define    RET_OK nullptr   // 定义操作成功时返回的宏

// 根据编译环境包含特定的头文件
#ifdef _WIN32
#include <Windows.h>
#include <direct.h>
#include <io.h>
#endif
// 包含必要的头文件
#include <string>
#include <vector>
#include <cstdio>
#include <opencv2/opencv.hpp>
#include "onnxruntime_cxx_api.h"

#ifdef USE_CUDA
#include <cuda_fp16.h>
#endif

// 定义模型类型枚举
enum MODEL_TYPE
{
    //FLOAT32 MODEL
    YOLO_DETECT_V8 = 1,         // 检测模型（FP32）
    YOLO_POSE = 2,              // 姿态估计模型
    YOLO_CLS = 3,               // 分类模型
    YOLO_SEG = 4,               // 分割模型

    //FLOAT16 MODEL
    YOLO_DETECT_V8_HALF = 5,    // 检测模型（FP16）
    YOLO_POSE_V8_HALF = 6,      // 姿态估计模型（FP16）
    YOLO_CLS_HALF = 7,          // 分类模型（FP16）
    YOLO_SEG_HALF = 8,          // 语义分割模型（FP16）
};

// 定义初始化参数的结构体
typedef struct _DL_INIT_PARAM
{
    std::string modelPath;                      // 模型路径
    MODEL_TYPE modelType = YOLO_DETECT_V8;      // 模型类型
    std::vector<int> imgSize = { 640, 640 };    // 输入图像尺寸
    bool cudaEnable = false;                    // 是否启用CUDA
    float rectConfidenceThreshold = 0.6;        // 检测框的置信度阈值
    float iouThreshold = 0.5;                   // IOU阈值，用于NMS
    int	keyPointsNum = 2;                       //Note:kpt number for pose 关节点数量，用于姿态估计
    int logSeverityLevel = 3;                   // 日志严重性等级
    int intraOpNumThreads = 1;                  // 内部操作的线程数
} DL_INIT_PARAM;

// 定义推理结果的结构体
typedef struct _DL_RESULT
{
    int classId;                                // 类别ID
    float confidence;                           // 置信度
    cv::Rect box;                               // 检测框
    cv::Mat boxMask;                            //矩形框内mask，节省内存空间和加快速度
    std::vector<cv::Point2f> keyPoints;         // 关键点，用于姿态估计
} DL_RESULT;

struct MaskParams {
    //int segChannels = 32;
    //int segWidth = 160;
    //int segHeight = 160;
    int netWidth = 640;
    int netHeight = 640;
    float maskThreshold = 0.5;
    cv::Size srcImgShape;
    cv::Vec4d params;

};

// YOLO_V8类声明
class YOLO_V8
{
public:
    YOLO_V8();                                  // 构造函数和析构函数

    ~YOLO_V8();

public:
    char* CreateSession(DL_INIT_PARAM& iParams);                        // 创建推理会话

    char* RunSession(cv::Mat& iImg, std::vector<DL_RESULT>& oResult);   // 运行推理会话

    char* WarmUpSession();                                              // 预热推理会话

    template<typename N>                                                // 模板函数，用于处理张量数据
    char* TensorProcess(clock_t& starttime_1, cv::Mat& iImg, N& blob, std::vector<int64_t>& inputNodeDims,
        std::vector<DL_RESULT>& oResult);

    char* PreProcess(cv::Mat& iImg, std::vector<int> iImgSize, cv::Mat& oImg);  // 预处理图像

    std::vector<std::string> classes{};                                 // 类别名称列表

private:                    // ONNX Runtime环境和会话
    Ort::Env env;
    Ort::Session* session;
    bool cudaEnable;
    Ort::RunOptions options;
    std::vector<const char*> inputNodeNames;
    std::vector<const char*> outputNodeNames;
    // 模型类型和图像尺寸
    MODEL_TYPE modelType;
    std::vector<int> imgSize;
    float rectConfidenceThreshold;
    float iouThreshold;
    float resizeScales;//letterbox scale
};
