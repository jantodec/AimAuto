//
// Created by jie on 5/25/24.
//
#pragma once                // 确保头文件内容只被包含一次

#include <iostream>
#include <iomanip>
#include "inference.h"
#include <filesystem>
#include <fstream>
#include <random>

//void Detector(YOLO_V8*& p , std::filesystem::path& image_path, bool isShow, bool isSave);
std::vector<DL_RESULT> Detector(YOLO_V8 *&p,
                                const std::filesystem::path& img_path_in,
                                bool isShow,
                                bool isSave);
//void Classifier(YOLO_V8*& p, std::filesystem::path& image_path, bool isShow, bool isSave);
std::vector<DL_RESULT> Classifier(YOLO_V8 *&p,
                                  const std::filesystem::path& img_path_in,
                                  bool isShow,
                                  bool isSave);
//void Segregator(YOLO_V8*& p, std::filesystem::path& image_path, bool isShow, bool isSave);
std::vector<DL_RESULT> Segregator(YOLO_V8 *&p,
                                 const std::filesystem::path& img_path_in,
                                 bool isShow,
                                 bool isSave);
int ReadDataYaml(YOLO_V8*& p, std::filesystem::path& yaml_path);
std::vector<DL_RESULT>  detector(const std::filesystem::path& model_path,
                                 const std::filesystem::path& yaml_path,
                                 const std::filesystem::path& img_path,
                                 MODEL_TYPE type,
                                 bool isShow,
                                 bool isSave);

