//
// Created by jie on 5/25/24.
//
#pragma once                // 确保头文件内容只被包含一次
#define PREDICTOR_H
#include "detector.h"
#include <cmath>
#include <vector>

// 定义状态向量和观测量
struct State {
    double x, y, z, theta;
    double vx, vy, vz, vtheta;
    double r;
};
struct Observation {
    double x, y, z, theta;
};

struct Camera {
    cv::Mat distCoeffs = cv::Mat::zeros(4, 1, CV_64F);
    cv::Mat cameraMatrix = (cv::Mat_<double>(3, 3) << 800, 0, 640, 0, 800, 360, 0, 0, 1);
};

// Define the Extended Kalman Filter class
class EKF {
public:
    EKF();
    void predict(double dt);
    void update(const Observation& obs);
    State getState();
    void Show();

private:
    cv::Mat x;  // State vector
    cv::Mat P;  // State covariance matrix
    cv::Mat Q;  // Process noise covariance matrix
    cv::Mat R;  // Measurement noise covariance matrix
    cv::Mat F;  // State transition matrix
    cv::Mat H;  // Measurement matrix
};

// Define the state machine states
enum TrackingState {
    DETECTING = 0,
    TRACKING = 1,
    TEMP_LOST = 2,
    LOST = 3
};

// Define the state machine class
class StateEstimate {
public:
    StateEstimate();
    ~StateEstimate();
    void update(bool detected);
    TrackingState getState();

private:
    TrackingState state;
    int trackCount;
    int lostCount;
    int trackThreshold;
    int lostThreshold;
};

class StateMachineManager {
public:
    void addStateMachine(int id);
    void removeStateMachine(int id);
    StateEstimate* getStateMachine(int id);
    void updateStateMachine(int id, bool detected, bool identified);
    void printState(int id);

private:
    std::unordered_map<int, StateEstimate> stateMachines;
};

std::vector<cv::Point3f> solver(const std::vector<cv::Point2f>& imagePoints);

