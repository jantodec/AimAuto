//
// Created by jie on 5/25/24.
//
#include "predictor.h"

// EKF class implementation
EKF::EKF()
{
// Initialize state vector
    this->x = (cv::Mat_<double>(9, 1) << 0, 0, 0, 0, 0, 0, 0, 0, 0);
// Initialize state covariance matrix
    this->P = cv::Mat::eye(9, 9, CV_64F);
// Initialize process noise covariance matrix
    this->Q = cv::Mat::eye(9, 9, CV_64F) * 0.1;
// Initialize measurement noise covariance matrix
    this->R = cv::Mat::eye(4, 4, CV_64F) * 0.1;
// Initialize state transition matrix (will be updated in predict step)
    this->F = cv::Mat::eye(9, 9, CV_64F);
// Initialize measurement matrix
    this->H = cv::Mat::zeros(4, 9, CV_64F);
    H.at<double>(0, 0) = 1;
    H.at<double>(1, 1) = 1;
    H.at<double>(2, 2) = 1;
    H.at<double>(3, 3) = 1;
}

void EKF::predict(double dt) {
    // Update the state transition matrix F based on the elapsed time dt
    F.at<double>(0, 4) = dt;
    F.at<double>(1, 5) = dt;
    F.at<double>(2, 6) = dt;
    F.at<double>(3, 7) = dt;

    // Predict the state vector
    x = F * x;

    // Predict the state covariance matrix
    P = F * P * F.t() + Q;
}

void EKF::update(const Observation& obs) {
    // Convert observation to matrix
    cv::Mat z = (cv::Mat_<double>(4, 1) << obs.x, obs.y, obs.z, obs.theta);

    // Compute the innovation
    cv::Mat y = z - H * x;

    // Compute the innovation covariance
    cv::Mat S = H * P * H.t() + R;

    // Compute the Kalman gain
    cv::Mat K = P * H.t() * S.inv();

    // Update the state vector
    x = x + K * y;

    // Update the state covariance matrix
    P = (cv::Mat::eye(9, 9, CV_64F) - K * H) * P;
}

State EKF::getState() {
    State state{};
    state.x = x.at<double>(0);
    state.y = x.at<double>(1);
    state.z = x.at<double>(2);
    state.theta = x.at<double>(3);
    state.vx = x.at<double>(4);
    state.vy = x.at<double>(5);
    state.vz = x.at<double>(6);
    state.vtheta = x.at<double>(7);
    state.r = x.at<double>(8);
    return state;
}

void EKF::Show() {
    std::cout<<"x:"<<x.at<double>(0)
            <<" y:"<< x.at<double>(1)
                    <<" z:"<<x.at<double>(2)
                            <<" theta:"<<x.at<double>(3)<<std::endl;
}

StateEstimate::StateEstimate(){
    this->trackCount = 0;
    this->lostCount = 0;
    this->trackThreshold = 3;
    this->lostThreshold = 80;
}

StateEstimate::~StateEstimate() {

}

// 传入本次检测状态，更新状态
void StateEstimate::update(bool detected)
{
    auto _state = this->state;
    int _trackCount = this->trackCount;
    int _lostCount = this->lostCount;
    if(detected)
    {
        this->trackCount++;
        this->lostCount = 0;
    }else
    {
        this->trackCount++;
        this->lostCount = 0;
    }

    switch (this->state) {
        case DETECTING:
        {
            if(this->trackCount > this->trackThreshold)
                this->state = TRACKING;
            break;
        }
        case TRACKING:
        {
            if (~detected)
                this->state = TEMP_LOST;
            break;
        }
        case TEMP_LOST:
        {
            if(detected)
                this->state = TRACKING;
            else if(this->lostCount > this->lostThreshold)
                this->state = LOST;
            break;
        }
        case LOST:
        {
            if(detected)
                this->state = DETECTING;
            break;
        }
        default:
            std::cout << "Error input state." << std::endl;
            break;
    }
}

TrackingState StateEstimate::getState() {
    return state;
}

// StateMachineManager class implementation
void StateMachineManager::addStateMachine(int id) {
    stateMachines[id] = StateEstimate();
}

void StateMachineManager::removeStateMachine(int id) {
    stateMachines.erase(id);
}

StateEstimate* StateMachineManager::getStateMachine(int id) {
    auto it = stateMachines.find(id);
    if (it != stateMachines.end()) {
        return &it->second;
    }
    return nullptr;
}

void StateMachineManager::updateStateMachine(int id, bool detected, bool identified) {
    auto it = stateMachines.find(id);
    if (it != stateMachines.end()) {
        it->second.update(detected);
    }
}

void StateMachineManager::printState(int id) {
    auto it = stateMachines.find(id);
    if (it != stateMachines.end()) {
        TrackingState state = it->second.getState();
        std::cout << "StateMachine ID " << id << " is in state: " << state << std::endl;
    } else {
        std::cout << "StateMachine ID " << id << " not found." << std::endl;
    }
}


std::vector<cv::Point3f> solver(std::vector<cv::Point2f> imagePoints, Camera camera)
{
    // 定义四个3D点的坐标（在物体坐标系中）
    std::vector<cv::Point3f> objectPoints;
    objectPoints.emplace_back(115, 0, -63.5);
    objectPoints.emplace_back(115, 0, 63.5);
    objectPoints.emplace_back(-115, 0, 63.5);
    objectPoints.emplace_back(-115, 0, -63.5);

//    // 定义四个对应的2D点的坐标（在图像坐标系中）
//    std::vector<cv::Point2f> imagePoints;
//    imagePoints.emplace_back(600, 550);
//    imagePoints.emplace_back(600, 600);
//    imagePoints.emplace_back(500, 600);
//    imagePoints.emplace_back(500, 550);

    // 定义相机内参矩阵（假设焦距为fx, fy，光心为(cx, cy)）
    //[fx   0   cx
    // 0    fy  cy
    // 0    0   1]
    cv::Mat cameraMatrix = camera.cameraMatrix;

    // 定义相机畸变系数（假设无畸变）
    cv::Mat distCoeffs = camera.distCoeffs;

    // 定义旋转向量和平移向量
    cv::Mat rvec, tvec;

    // 使用IPPE算法解决P4P问题
    bool useExtrinsicGuess = false;
    int flags = cv::SOLVEPNP_IPPE;

    bool success = cv::solvePnP(objectPoints, imagePoints, cameraMatrix, distCoeffs, rvec, tvec, useExtrinsicGuess, flags);
    if (success) {
        // 打印结果
        std::cout << "Rotation Vector (rvec): " << rvec.t() << std::endl;
        std::cout << "Translation Vector (tvec): " << tvec.t() << std::endl;

        // 将旋转向量转换为旋转矩阵
        cv::Mat rotationMatrix;
        cv::Rodrigues(rvec, rotationMatrix);
        std::cout << "Rotation Matrix: " << std::endl << rotationMatrix << std::endl;
    } else {
        std::cerr << "PnP problem solving failed!" << std::endl;
    }

//
//    // 构造4x4的齐次变换矩阵
//    cv::Mat Mex = cv::Mat::eye(4, 4, CV_64F);
//    R.copyTo(Mex(cv::Rect(0, 0, 3, 3)));
//    tvec.copyTo(Mex(cv::Rect(3, 0, 1, 3)));

    // 将旋转向量转换为旋转矩阵
    cv::Mat R;
    cv::Rodrigues(rvec, R);

    // 将世界坐标系中的点转换到相机坐标系
    std::vector<cv::Point3f> cameraPoints;
    for (const auto& pt : objectPoints) {
        cv::Mat ptMat = (cv::Mat_<double>(3, 1) << pt.x, pt.y, pt.z);
        cv::Mat cameraPtMat = R * ptMat + tvec;
        cv::Point3f cameraPt(cameraPtMat.at<double>(0), cameraPtMat.at<double>(1), cameraPtMat.at<double>(2));
        cameraPoints.push_back(cameraPt);
    }
//
//    // 输出相机坐标系中的点
//    for (const auto& pt : cameraPoints) {
//        std::cout << "Camera Coordinate: (" << pt.x << ", " << pt.y << ", " << pt.z << ")" << std::endl;
//    }

    return cameraPoints;
}

// 计算向量叉积
std::vector<double> crossProduct(const std::vector<double>& a, const std::vector<double>& b) {
    return {
            a[1] * b[2] - a[2] * b[1],
            a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0]
    };
}

// 计算与 x 轴的夹角
double calculateAngle(const std::vector<double>& D) {
    return atan2(D[1], D[0]);
}

void EKFPredictor(std::vector<std::vector<cv::Point3_<float>>> result)
{
    //EFK预测
    EKF predictor;
    std::vector<Observation> ObjImg;
    // 矩形四个顶点的坐标
    for(auto& re:result)
    {
        std::vector<cv::Point3_<float>> vertices;
        for(int k = 0;k<4;k++)
        {
            vertices.push_back(re.at(k));
        }


        // 计算 AB 和 AC 向量
        std::vector<double> AB = {vertices[1].x - vertices[0].x, vertices[1].y - vertices[0].y, vertices[1].z - vertices[0].z};
        std::vector<double> AC = {vertices[2].x - vertices[0].x, vertices[2].y - vertices[0].y, vertices[2].z - vertices[0].z};

        // 计算法向量 N
        std::vector<double> N = crossProduct(AB, AC);

        // XOY 平面的法向量
        std::vector<double> zAxis = {0.0, 0.0, 1.0};

        // 计算交线方向向量 D
        std::vector<double> D = crossProduct(N, zAxis);

        // 计算与 x 轴的夹角
        double angle = calculateAngle(D);

        ObjImg.push_back({ vertices[0].x,vertices[0].y,vertices[0].z, angle* 180.0 / M_PI});
    }


    predictor.update(ObjImg[5]);
    predictor.Show();
    predictor.predict(0.2);
    predictor.Show();
    predictor.update(ObjImg[4]);
    predictor.Show();
    predictor.predict(0.2);
    predictor.Show();
    predictor.update(ObjImg[0]);
    predictor.Show();
    predictor.predict(0.2);
    predictor.Show();
    predictor.update(ObjImg[2]);
    predictor.Show();
    predictor.predict(0.2);
    predictor.Show();
    predictor.update(ObjImg[3]);
    predictor.Show();
    predictor.predict(0.2);
    predictor.Show();
    predictor.update(ObjImg[6]);
    predictor.Show();
    predictor.predict(0.2);
    predictor.Show();
}

int main()
{
    std::filesystem::path current_path = std::filesystem::current_path().parent_path();
    std::filesystem::path model_path = current_path / "models/yolov8n_seg_final.onnx";// / "model"
    std::filesystem::path yaml_path = current_path / "models/data.yaml";// / "yaml_file"
    std::filesystem::path imgs_path = current_path / "images/";// / "images"
    Camera camera;
    std::vector<std::vector<cv::Point3_<float>>> result;
    int j = 0;
    for (auto &i: std::filesystem::directory_iterator(imgs_path))
    {
        if (i.path().extension() == ".jpg" || i.path().extension() == ".png")
        {
            std::cout<< i.path().filename() <<std::endl;
            auto res = detector(model_path, yaml_path, i.path(),YOLO_SEG, false, false);
            StateEstimate Estimate;
            for (auto &re: res)
            {
                std::vector<cv::Point2f> ObjImg;
                ObjImg.emplace_back(re.box.x + re.box.width/2,re.box.y - re.box.height/2);
                ObjImg.emplace_back(re.box.x + re.box.width/2,re.box.y + re.box.height/2);
                ObjImg.emplace_back(re.box.x - re.box.width/2,re.box.y + re.box.height/2);
                ObjImg.emplace_back(re.box.x - re.box.width/2,re.box.y - re.box.height/2);

                auto xyz =  solver(ObjImg, camera);
                std::cout<< j << ":" << re.classId <<std::endl;
                std::cout<< xyz <<std::endl;
                j++;
                result.push_back(xyz);
            }
        }
    }
    EKFPredictor(result);
    return 0;
}



//    std::filesystem::path current_path = std::filesystem::current_path().parent_path();
//    std::filesystem::path model_path = current_path / "models/yolov8n_seg_final.onnx";// / "model"
//    std::filesystem::path yaml_path = current_path / "models/data.yaml";// / "yaml_file"
//    std::filesystem::path imgs_path = current_path / "images/images";// / "images"

