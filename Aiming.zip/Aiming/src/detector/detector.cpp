#include "detector.h"

//void Detector(YOLO_V8*& p , const std::filesystem::path& imgs_path, bool isShow, bool isSave) {
//
//    for (auto& i : std::filesystem::directory_iterator(imgs_path))
//    {
//        if (i.path().extension() == ".jpg" || i.path().extension() == ".png" || i.path().extension() == ".jpeg")
//        {
//            std::string img_path = i.path().string();
//            cv::Mat img = cv::imread(img_path);
//            std::vector<DL_RESULT> res;
//            p->RunSession(img, res);
//
//            for (auto& re : res)
//            {
//                cv::RNG rng(cv::getTickCount());
//                cv::Scalar color(rng.uniform(0, 256), rng.uniform(0, 256), rng.uniform(0, 256));
//
//                cv::rectangle(img, re.box, color, 3);
//
//                float confidence = floor(100 * re.confidence) / 100;
//                std::cout << std::fixed << std::setprecision(2);
//                std::string label = p->classes[re.classId] + " " +
//                                    std::to_string(confidence).substr(0, std::to_string(confidence).size() - 4);
//
//                cv::rectangle(
//                        img,
//                        cv::Point(re.box.x, re.box.y - 25),
//                        cv::Point(re.box.x + label.length() * 15, re.box.y),
//                        color,
//                        cv::FILLED
//                );
//
//                cv::putText(
//                        img,
//                        label,
//                        cv::Point(re.box.x, re.box.y - 5),
//                        cv::FONT_HERSHEY_SIMPLEX,
//                        0.75,
//                        cv::Scalar(0, 0, 0),
//                        2
//                );
//
//            }
//            if(isShow)//展示处理过的图片
//            {
//                cv::imshow("Result of Detector\"", img);
//                cv::waitKey(0);
//                cv::destroyAllWindows();
//            }
//
//            if(isSave)//储存处理过的图片
//            {
//                std::filesystem::path output_path = imgs_path.parent_path() / "images/output/";// / "images"
//                if(!cv::imwrite(output_path.string() + i.path().filename().string() , img))
//                {
//                    std::cout<<"Failed to save image."<<std::endl;
//                }
//            }
//        }
//    }
//}
//
//
//void Classifier(YOLO_V8*& p, const std::filesystem::path& imgs_path, bool isShow, bool isSave) {
//    std::random_device rd;
//    std::mt19937 gen(rd());
//    std::uniform_int_distribution<int> dis(0, 255);
//    for (auto &i: std::filesystem::directory_iterator(imgs_path)) {
//        if (i.path().extension() == ".jpg" || i.path().extension() == ".png") {
//            std::string img_path = i.path().string();
//            //std::cout << img_path << std::endl;
//            cv::Mat img = cv::imread(img_path);
//            std::vector<DL_RESULT> res;
//            char *ret = p->RunSession(img, res);
//
//            float positionY = 50;
//            for (int i = 0; i < res.size(); i++) {
//                int r = dis(gen);
//                int g = dis(gen);
//                int b = dis(gen);
//                cv::putText(img, std::to_string(res.at(i).classId) + ":", cv::Point(10, positionY),
//                            cv::FONT_HERSHEY_SIMPLEX, 1, cv::Scalar(b, g, r), 2);
//                cv::putText(img, std::to_string(res.at(i).confidence), cv::Point(70, positionY),
//                            cv::FONT_HERSHEY_SIMPLEX, 1, cv::Scalar(b, g, r), 2);
//                positionY += 50;
//            }
//            if (isShow)//展示处理过的图片
//            {
//                cv::imshow("Result of Classifier\"", img);
//                cv::waitKey(0);
//                cv::destroyAllWindows();
//            }
//
//            if (isSave)//储存处理过的图片
//            {
//                std::filesystem::path output_path = imgs_path.parent_path() / "images/output/";// / "images"
//                if (!cv::imwrite(output_path.string() + i.path().filename().string(), img)) {
//                    std::cout << "Failed to save image." << std::endl;
//                }
//            }
//        }
//    }
//}
//
//
//void Segregator(YOLO_V8 *&p, const std::filesystem::path &imgs_path, bool isShow, bool isSave) {
//    std::random_device rd;
//    std::mt19937 gen(rd());
//    std::uniform_int_distribution<int> dis(0, 255);
//    for (auto &i: std::filesystem::directory_iterator(imgs_path)) {
//        if (i.path().extension() == ".jpg" || i.path().extension() == ".png") {
//            std::string img_path = i.path().string();
//            //std::cout << img_path << std::endl;
//            cv::Mat img = cv::imread(img_path);
//            std::vector<DL_RESULT> res;
//            p->RunSession(img, res);
//
//            //绘制结果
//            float positionY = 50;
//            for (auto &re: res) {
//                cv::RNG rng(cv::getTickCount());
//                cv::Scalar color(rng.uniform(0, 256), rng.uniform(0, 256), rng.uniform(0, 256));
//
//                cv::rectangle(img, re.box, color, 3);
//
//                float confidence = floor(100 * re.confidence) / 100;
//                std::cout << std::fixed << std::setprecision(2);
//                std::string label = p->classes[re.classId] + " " +
//                                    std::to_string(confidence).substr(0, std::to_string(confidence).size() - 4);
//
//                cv::rectangle(
//                        img,
//                        cv::Point(re.box.x, re.box.y - 25),
//                        cv::Point(re.box.x + label.length() * 15, re.box.y),
//                        color,
//                        cv::FILLED
//                );
//
//                cv::putText(
//                        img,
//                        label,
//                        cv::Point(re.box.x, re.box.y - 5),
//                        cv::FONT_HERSHEY_SIMPLEX,
//                        0.75,
//                        cv::Scalar(0, 0, 0),
//                        2);
//                positionY += 50;
//            }
//            if (isShow)//展示处理过的图片
//            {
//                cv::imshow("Result of Segment\"", img);
//                cv::waitKey(0);
//                cv::destroyAllWindows();
//            }
//            if (isSave)//储存处理过的图片
//            {
//                std::filesystem::path output_path = imgs_path.parent_path() / "images/output/";// / "images"
//                if (!cv::imwrite(output_path.string() + i.path().filename().string(), img)) {
//                    std::cout << "Failed to save image." << std::endl;
//                }
//            }
//        }
//    }
//}

std::vector<DL_RESULT> Detector(YOLO_V8 *&p,
                                const std::filesystem::path& img_path_in,
                                bool isShow,
                                bool isSave)
{
    std::vector<DL_RESULT> res;
    std::string img_path = img_path_in;
    cv::Mat img = cv::imread(img_path);
    p->RunSession(img, res);

    for (auto& re : res)
    {
        cv::RNG rng(cv::getTickCount());
        cv::Scalar color(rng.uniform(0, 256), rng.uniform(0, 256), rng.uniform(0, 256));

        cv::rectangle(img, re.box, color, 3);

        float confidence = floor(100 * re.confidence) / 100;
        std::cout << std::fixed << std::setprecision(2);
        std::string label = p->classes[re.classId] + " " +
                            std::to_string(confidence).substr(0, std::to_string(confidence).size() - 4);

        cv::rectangle(
                img,
                cv::Point(re.box.x, re.box.y - 25),
                cv::Point(re.box.x + label.length() * 15, re.box.y),
                color,
                cv::FILLED
        );

        cv::putText(
                img,
                label,
                cv::Point(re.box.x, re.box.y - 5),
                cv::FONT_HERSHEY_SIMPLEX,
                0.75,
                cv::Scalar(0, 0, 0),
                2
        );

    }
    if(isShow)//展示处理过的图片
    {
        cv::imshow("Result of Detector\"", img);
        cv::waitKey(0);
        cv::destroyAllWindows();
    }

    if(isSave)//储存处理过的图片
    {
        std::filesystem::path output_path = img_path_in.parent_path() / "output/";// / "images"
        if(!cv::imwrite(output_path.string() + img_path_in.filename().string() , img))
        {
            std::cout<<"Failed to save image."<<std::endl;
        }
    }

    return res;
}


std::vector<DL_RESULT> Classifier(YOLO_V8 *&p,
                                  const std::filesystem::path& img_path_in,
                                  bool isShow,
                                  bool isSave)
{
    std::vector<DL_RESULT> res;
    std::string img_path = img_path_in;
    cv::Mat img = cv::imread(img_path);
    p->RunSession(img, res);

    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int> dis(0, 255);

    float positionY = 50;
    for (auto & re : res) {
        int r = dis(gen);
        int g = dis(gen);
        int b = dis(gen);
        cv::putText(img, std::to_string(re.classId) + ":", cv::Point(10, positionY),
                    cv::FONT_HERSHEY_SIMPLEX, 1, cv::Scalar(b, g, r), 2);
        cv::putText(img, std::to_string(re.confidence), cv::Point(70, positionY),
                    cv::FONT_HERSHEY_SIMPLEX, 1, cv::Scalar(b, g, r), 2);
        positionY += 50;
    }
    if(isShow)//展示处理过的图片
    {
        cv::imshow("Result of Classifier\"", img);
        cv::waitKey(0);
        cv::destroyAllWindows();
    }

    if(isSave)//储存处理过的图片
    {
        std::filesystem::path output_path = img_path_in.parent_path() / "output/";// / "images"
        if(!cv::imwrite(output_path.string() + img_path_in.filename().string() , img))
        {
            std::cout<<"Failed to save image."<<std::endl;
        }
    }

    return res;
}


std::vector<DL_RESULT> Segregator(YOLO_V8 *&p,
                                  const std::filesystem::path& img_path_in,
                                  bool isShow,
                                  bool isSave)
{
    std::vector<DL_RESULT> res;
    std::string img_path = img_path_in;
    cv::Mat img = cv::imread(img_path);
    p->RunSession(img, res);

    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int> dis(0, 255);

    float positionY = 50;
    for (auto &re: res) {
        cv::RNG rng(cv::getTickCount());
        cv::Scalar color(rng.uniform(0, 256), rng.uniform(0, 256), rng.uniform(0, 256));

        cv::rectangle(img, re.box, color, 3);

        float confidence = floor(100 * re.confidence) / 100;
        std::cout << std::fixed << std::setprecision(2);
        std::string label = p->classes[re.classId] + " " +
                            std::to_string(confidence).substr(0, std::to_string(confidence).size() - 4);

        cv::rectangle(
                img,
                cv::Point(re.box.x, re.box.y - 25),
                cv::Point(re.box.x + label.length() * 15, re.box.y),
                color,
                cv::FILLED
        );

        cv::putText(
                img,
                label,
                cv::Point(re.box.x, re.box.y - 5),
                cv::FONT_HERSHEY_SIMPLEX,
                0.75,
                cv::Scalar(0, 0, 0),
                2);
        positionY += 50;
    }
    if(isShow)//展示处理过的图片
    {
        cv::imshow("Result of Classifier\"", img);
        cv::waitKey(0);
        cv::destroyAllWindows();
    }

    if(isSave)//储存处理过的图片
    {
        std::filesystem::path output_path = img_path_in.parent_path() / "output/";// / "images"
        if(!cv::imwrite(output_path.string() + img_path_in.filename().string() , img))
        {
            std::cout<<"Failed to save image."<<std::endl;
        }
    }
    return res;
}


int ReadDataYaml(YOLO_V8 *&p, const std::filesystem::path &yaml_path) {
    // Open the YAML file
    std::ifstream file(yaml_path.string());
    if (!file.is_open()) {
        std::cerr << "Failed to open file" << std::endl;
        return 1;
    }

    // Read the file line by line
    std::string line;
    std::vector<std::string> lines;
    while (std::getline(file, line)) {
        lines.push_back(line);
    }

    // Find the start and end of the names section
    std::size_t start = 0;
    std::size_t end = 0;
    for (std::size_t i = 0; i < lines.size(); i++) {
        if (lines[i].find("names:") != std::string::npos) {
            start = i + 1;
        } else if (start > 0 && lines[i].find(':') == std::string::npos) {
            end = i;
            break;
        }
    }

    // Extract the names
    std::vector<std::string> names;
    for (std::size_t i = start; i < end; i++) {
        std::stringstream ss(lines[i]);
        std::string name;
        std::getline(ss, name, ':'); // Extract the number before the delimiter
        std::getline(ss, name); // Extract the string after the delimiter
        names.push_back(name);
    }

    p->classes = names;
    return 0;
}

std::vector<DL_RESULT>  detector(const std::filesystem::path& model_path,
                                 const std::filesystem::path& yaml_path,
                                 const std::filesystem::path& img_path,
                                 MODEL_TYPE type,
                                 bool isShow,
                                 bool isSave)
{
    auto *yoloDetector = new YOLO_V8;
    ReadDataYaml(yoloDetector, yaml_path);
    DL_INIT_PARAM params;
    params.rectConfidenceThreshold = 0.1;
    params.iouThreshold = 0.5;
    params.modelPath = model_path;
    params.imgSize = {640, 640};
    // GPU FP16 inference
    //Note: change fp16 onnx model
    params.modelType = type;

#ifdef USE_CUDA
    // GPU FP32 inference
    params.cudaEnable = true;
#else
    // CPU inference
    params.cudaEnable = false;
#endif
    yoloDetector->CreateSession(params);
    std::vector<DL_RESULT> res;
    switch (type)
    {
        case YOLO_DETECT_V8:
        case YOLO_DETECT_V8_HALF: {
            res =  Detector(yoloDetector, img_path, isShow, isSave);
            break;
        }

        case YOLO_CLS:
        case YOLO_CLS_HALF: {
            res =  Classifier(yoloDetector, img_path, isShow, isSave);
            break;
        }
        case YOLO_SEG:
        case YOLO_SEG_HALF: {
            res =  Segregator(yoloDetector, img_path, isShow, isSave);
            break;
        }
        default:
            std::cout << "[YOLO_V8]: " << "Not support model type." << std::endl;
    }
    return res;
}


